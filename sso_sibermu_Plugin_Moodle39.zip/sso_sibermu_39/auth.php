<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * SSO SiberMu Authentication Plugin.
 *
 * @package    auth_sso_sibermu
 * @copyright  2025 Joko Supriyanto (joko@sibermu.ac.id)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/authlib.php');

/**
 * SSO SiberMu authentication plugin class.
 *
 * @package    auth_sso_sibermu
 */
class auth_plugin_sso_sibermu extends auth_plugin_base {

    /**
     * Constructor.
     */
    public function __construct() {
        $this->authtype = 'sso_sibermu';
        $this->config = get_config('auth/sso_sibermu');
    }

    /**
     * Hook to add the SSO button to the login page.
     *
     * @return void
     */
    public function loginpage_hook() {
        global $OUTPUT, $DB;

        $loginUrl = new moodle_url('/auth/sso_sibermu/login.php', ['sesskey' => sesskey()]);
        $buttonTextFromDb = $DB->get_field('config_plugins', 'value', ['plugin' => 'auth_sso_sibermu', 'name' => 'login_button_text']);

        if (!empty(trim($buttonTextFromDb))) {
            $buttonText = $buttonTextFromDb;
        } else {
            $buttonText = 'Login with SSO SiberMu';
        }

 // 1. Dapatkan URL logo dari direktori /pix/ plugin.
        // Ganti 'logo_sso' dengan nama file PNG Anda tanpa ekstensi .png
        $logoUrl = $OUTPUT->pix_url('logo_sso', 'auth_sso_sibermu');

        // 2. Buat HTML untuk tombol yang berisi logo dan teks.
        $buttonHtmlName = '<img src="' . $logoUrl . '" alt="SSO Logo" style="height: 30px; vertical-align: middle; margin-right: 8px;"> ' . $buttonText;

        // 3. Siapkan data untuk template dengan HTML baru dan kosongkan iconurl.
        $templateData = [
            'idps' => [[
                'name' => $buttonHtmlName, // Menggunakan HTML yang sudah ada logonya
                'url' => $loginUrl->out(false),
                'iconurl' => '', // Dikosongkan karena kita sudah pakai logo sendiri
            ]]
        ];

        // 1. Get the placement selector value directly from the database.
        $selectorFromDb = $DB->get_field(
            'config_plugins',
            'value',
            [
                'plugin' => 'auth_sso_sibermu',
                'name'   => 'button_placement_selector'
            ]
        );

        // 2. Use the value from the database. If empty, use '.loginform' as the default.
        $placementSelector = !empty(trim($selectorFromDb)) ? $selectorFromDb : '.loginform';

        // 3. Encode the selector for security when inserting into JavaScript.
        $jsSelector = json_encode($placementSelector);

        // Render the SSO button, wrapped in a div for easy discovery.
        echo '<div id="sso_sibermu_button_container" style="display: none;">';
        echo $OUTPUT->render_from_template('auth_sso_sibermu/button', $templateData);
        echo '</div>';

        // 4. Pass the selector variable from PHP into JavaScript.
        echo <<<HTML
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ssoButtonContainer = document.getElementById('sso_sibermu_button_container');

        // Use the custom selector from the plugin settings.
        const oauthProvidersContainer = document.querySelector({$jsSelector});

        if (ssoButtonContainer && oauthProvidersContainer) {
            oauthProvidersContainer.appendChild(ssoButtonContainer);
            ssoButtonContainer.style.display = 'block';
        } else if (ssoButtonContainer) {
            // If the selector is not found, display the button in its default position (at the top).
            ssoButtonContainer.style.display = 'block';
        }
    });
</script>
HTML;
    }

    /**
     * Handles the user logout process for Single Log-Out (SLO).
     *
     * @return void
     */
    public function user_logout() {
        global $CFG;

        // 1. End the Moodle session first. This is a crucial step.
        require_logout();

        // 2. After the Moodle session has ended, redirect to the SSO server for Single Log-Out.
        if (empty($this->config->sso_server_url)) {
            // If the SSO logout URL is not set, the process ends here.
            return;
        }

        $redirecturi = new moodle_url('/login/index.php');
        $logoutUrl = new moodle_url(
            $this->config->sso_server_url . '/logout.php',
            ['redirect_uri' => $redirecturi->out(false)]
        );

        redirect($logoutUrl->out(true));
    }

    /**
     * Synchronizes user data from SSO with Moodle.
     * It finds an existing user in Moodle based on the 'nisn' field from SSO,
     * which is mapped to the 'username' field in Moodle.
     *
     * @param  \stdClass $ssoUser The user data object from the SSO server.
     * @return \stdClass|false The Moodle user object if found, otherwise false.
     */
    public function sync_user_data(\stdClass $ssoUser) {
        global $DB;

        // 1. Validate data from SSO, ensure 'nisn' (which we treat as username) is not empty.
        if (empty($ssoUser->nisn)) {
            return false;
        }

        // 2. Get the 'nisn' value from SSO. This will be matched against the 'username' column in Moodle.
        $ssoUsername = $ssoUser->nisn;

        // 3. Find the user in Moodle by 'username'.
        // We also ensure the user is not deleted (deleted = 0).
        $user = $DB->get_record('user', [
            'username' => $ssoUsername,
            'deleted'  => 0,
        ]);

        // 4. Return the user object if found to allow the login process to continue.
        // If not found, return false to fail the login.
        if ($user) {
            return $user;
        } else {
            return false;
        }
    }
}